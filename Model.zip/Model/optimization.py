import numpy
import theano
import theano.tensor as T
from numpy import *

def get_optimizer(optimization, l_rate, eps = 1e-8, decay = 0.9, momentum = 0.9, clipping = False ):
	return RMSProp(l_rate, eps, decay, clipping)

class RMSProp(Optimizer):

	def __init__(self, l_rate, epsilon, decay, clipping):
		Optimizer.__init__(self, l_rate, clipping)
		self.epsilon = epsilon
		self.decay = decay

	def register_variable(self, variable_name, rows, cols):
		if(rows!=1):
			self.wlist[variable_name] = theano.shared(value=numpy.zeros((rows,cols),dtype=theano.config.floatX),borrow=True)
		else:
			self.wlist[variable_name] = theano.shared(value=numpy.zeros(cols,dtype=theano.config.floatX),borrow=True)

	def get_grad_update(self, variable_name, grad_matrix):
		up = []
		grad_matrix = self.clip(grad_matrix)
		new_w = self.decay * self.wlist[variable_name] + (1 - self.decay) * (grad_matrix ** 2)
		rms_w = T.sqrt(new_w+self.epsilon)
		update =  - ((self.l_rate / rms_w) * grad_matrix)
		up.append((self.wlist[variable_name],new_w))
		return update, up




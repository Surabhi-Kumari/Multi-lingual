import os
import numpy
from scipy import sparse

import theano.tensor as T


def create_folder(folder):
	if not os.path.exists(folder):
		os.makedirs(folder)

def denseTheanoloader(file, x, bit):
	lang = denseloader(file, bit)
	x.set_value(lang, borrow=True)


def sparseTheanoloader(file, x, bit, row, col):
	lang = sparseloader(file, bit, row, col)
	x.set_value(lang, borrow=True)


def denseloader(file, bit):
	matrix = numpy.load(file + ".npy")
	matrix = numpy.array(matrix, dtype=bit)
	return matrix


def sparseloader(file, bit, row, col):
	print "loading ...", file
	x = numpy.load(file + "d.npy")
	y = numpy.load(file + "i.npy")
	z = numpy.load(file + "p.npy")
	matrix = sparse.csr_matrix((x, y, z), shape=(row, col), dtype=bit)
	matrix = matrix.todense()
	return matrix



def activation(x, function):
	if (function == "sigmoid"):
		return T.nnet.sigmoid(x)
	


def loss(pred, tgt, function):
	if (function == "squarrederror"):
		return T.sum(T.sqr(tgt - pred) / 2, axis=1)
	



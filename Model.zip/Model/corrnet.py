import pickle
from optimization import *
from Initializer import *
from NNUtil import *


import theano.tensor as T
from theano.tensor.shared_randomstreams import RandomStreams

class CorrNet(object):

    def init(self, numpy_rng, theano_rng=None, l_rate=0.01, optimization="sgd",
             tied=False, n_visible_hindi=None, n_visible_english=None, n_hidden=None, lamda=5,
             W_hindi=None, W_english=None, b=None, W_hindi_prime=None, W_english_prime=None,
             b_prime_hindi=None, b_prime_english=None, input_hindi=None, input_english=None,
             hidden_activation="sigmoid", output_activation="sigmoid", loss_fn = "squarrederror",
             op_folder=None):

        self.numpy_rng = numpy_rng
        if not theano_rng:
            theano_rng = RandomStreams(numpy_rng.randint(2 ** 30))
        self.theano_rng = theano_rng

        self.optimization = optimization
        self.l_rate = l_rate

        self.optimizer = get_optimizer(self.optimization, self.l_rate)
        self.Initializer = Initializer(self.numpy_rng)

        self.n_visible_hindi = n_visible_hindi
        self.n_visible_english = n_visible_english
        self.n_hidden = n_hidden
        self.lamda = lamda
        self.hidden_activation = hidden_activation
        self.output_activation = output_activation
        self.loss_fn = loss_fn
        self.tied = tied
        self.op_folder = op_folder

        self.W_hindi = self.Initializer.fan_based_sigmoid("W_hindi", W_hindi, n_visible_hindi, n_hidden)
        self.optimizer.register_variable("W_hindi",n_visible_hindi,n_hidden)

        self.W_english = self.Initializer.fan_based_sigmoid("W_english", W_english, n_visible_english, n_hidden)
        self.optimizer.register_variable("W_english",n_visible_english,n_hidden)

        if not tied:
            self.W_hindi_prime = self.Initializer.fan_based_sigmoid("W_hindi_prime", W_hindi_prime, n_hidden, n_visible_hindi)
            self.optimizer.register_variable("W_hindi_prime",n_hidden, n_visible_hindi)
            self.W_english_prime = self.Initializer.fan_based_sigmoid("W_english_prime", W_english_prime, n_hidden, n_visible_english)
            self.optimizer.register_variable("W_english_prime",n_hidden, n_visible_english)
        else:
            self.W_hindi_prime = self.W_hindi.T
            self.W_english_prime = self.W_english.T

        self.b = self.Initializer.zero_vector("b", b, n_hidden)
        self.optimizer.register_variable("b",1,n_hidden)

        self.b_prime_hindi = self.Initializer.zero_vector("b_prime_hindi", b_prime_hindi, n_visible_hindi)
        self.optimizer.register_variable("b_prime_hindi",1,n_visible_hindi)
        self.b_prime_english = self.Initializer.zero_vector("b_prime_english", b_prime_english, n_visible_english)
        self.optimizer.register_variable("b_prime_english",1,n_visible_english)

        if input_hindi is None:
            self.x_hindi = T.matrix(name='x_hindi')
        else:
            self.x_hindi = input_hindi

        if input_english is None:
            self.x_english = T.matrix(name='x_english')
        else:
            self.x_english = input_english


        if tied:
            self.params = [self.W_hindi, self.W_english,  self.b, self.b_prime_hindi, self.b_prime_english]
            self.param_names = ["W_hindi", "W_english", "b", "b_prime_hindi", "b_prime_english"]
        else:
            self.params = [self.W_hindi, self.W_english,  self.b, self.b_prime_hindi, self.b_prime_english, self.W_hindi_prime, self.W_english_prime]
            self.param_names = ["W_hindi", "W_english", "b", "b_prime_hindi", "b_prime_english", "W_hindi_prime", "W_english_prime"]


        self.proj_from_hindi = theano.function([self.x_hindi],self.project_from_hindi())
        self.proj_from_english = theano.function([self.x_english],self.project_from_english())
        self.recon_from_hindi = theano.function([self.x_hindi],self.reconstruct_from_hindi())
        self.recon_from_english = theano.function([self.x_english],self.reconstruct_from_english())

        self.save_params()


    def train_common(self,mtype="1111"):

        y1_pre = T.dot(self.x_hindi, self.W_hindi) + self.b
        y1 = activation(y1_pre, self.hidden_activation)
        z1_hindi_pre = T.dot(y1, self.W_hindi_prime) + self.b_prime_hindi
        z1_english_pre = T.dot(y1,self.W_english_prime) + self.b_prime_english
        z1_hindi = activation(z1_hindi_pre, self.output_activation)
        z1_english = activation(z1_english_pre, self.output_activation)
        L1 = loss(z1_hindi, self.x_hindi, self.loss_fn) + loss(z1_english, self.x_english, self.loss_fn)

        y2_pre = T.dot(self.x_english, self.W_english) + self.b
        y2 = activation(y2_pre, self.hidden_activation)
        z2_hindi_pre = T.dot(y2, self.W_hindi_prime) + self.b_prime_hindi
        z2_english_pre = T.dot(y2,self.W_english_prime) + self.b_prime_english
        z2_hindi = activation(z2_hindi_pre, self.output_activation)
        z2_english = activation(z2_english_pre, self.output_activation)
        L2 = loss(z2_hindi, self.x_hindi, self.loss_fn) + loss(z2_english, self.x_english, self.loss_fn)

        y3_pre = T.dot(self.x_hindi, self.W_hindi) + T.dot(self.x_english, self.W_english) + self.b
        y3 = activation(y3_pre, self.hidden_activation)
        z3_hindi_pre = T.dot(y3, self.W_hindi_prime) + self.b_prime_hindi
        z3_english_pre = T.dot(y3,self.W_english_prime) + self.b_prime_english
        z3_hindi = activation(z3_hindi_pre, self.output_activation)
        z3_english = activation(z3_english_pre, self.output_activation)
        L3 = loss(z3_hindi, self.x_hindi, self.loss_fn) + loss(z3_english, self.x_english, self.loss_fn)

        y1_mean = T.mean(y1, axis=0)
        y1_centered = y1 - y1_mean
        y2_mean = T.mean(y2, axis=0)
        y2_centered = y2 - y2_mean
        corr_nr = T.sum(y1_centered * y2_centered, axis=0)
        corr_dr1 = T.sqrt(T.sum(y1_centered * y1_centered, axis=0)+1e-8)
        corr_dr2 = T.sqrt(T.sum(y2_centered * y2_centered, axis=0)+1e-8)
        corr_dr = corr_dr1 * corr_dr2
        corr = corr_nr/corr_dr
        L4 = T.sum(corr) * self.lamda

        ly4_pre = T.dot(self.x_hindi, self.W_hindi) + self.b
        ly4 = activation(ly4_pre, self.hidden_activation)
        lz4_english_pre = T.dot(ly4,self.W_english_prime) + self.b_prime_english
        lz4_english = activation(lz4_english_pre, self.output_activation)
        ry4_pre = T.dot(self.x_english, self.W_english) + self.b
        ry4 = activation(ry4_pre, self.hidden_activation)
        rz4_hindi_pre = T.dot(ry4,self.W_hindi_prime) + self.b_prime_hindi
        rz4_hindi = activation(rz4_hindi_pre, self.output_activation)
        L5 = loss(lz4_english, self.x_english, self.loss_fn) + loss(rz4_hindi, self.x_hindi, self.loss_fn)
        L = L1 + L2 + L3 - L4
        total_loss = T.mean(L)

        gradients = T.grad(total_loss, self.params)
        updates = []
        for p,g,n in zip(self.params, gradients, self.param_names):
            gr, upd = self.optimizer.get_grad_update(n,g)
            updates.append((p,p+gr))
            updates.extend(upd)

        return total_loss, updates

    def train_hindi(self):

        y_pre = T.dot(self.x_hindi, self.W_hindi) + self.b
        y = activation(y_pre, self.hidden_activation)
        z_hindi_pre = T.dot(y, self.W_hindi_prime) + self.b_prime_hindi
        z_hindi = activation(z_hindi_pre, self.output_activation)
        L = loss(z_hindi, self.x_hindi, self.loss_fn)
        total_loss = T.mean(L)

        if self.tied:
            curr_params = [self.W_hindi, self.b, self.b_prime_hindi]
            curr_param_names = ["W_hindi", "b", "b_prime_hindi"]
        else:
            curr_params = [self.W_hindi, self.b, self.b_prime_hindi, self.W_hindi_prime]
            curr_param_names = ["W_hindi", "b", "b_prime_hindi", "W_hindi_prime"]

        gradients = T.grad(total_loss, curr_params)
        updates = []
        for p,g,n in zip(curr_params, gradients, curr_param_names):
            gr, upd = self.optimizer.get_grad_update(n,g)
            updates.append((p,p+gr))
            updates.extend(upd)
        return total_loss, updates

    def train_english(self):

        y_pre = T.dot(self.x_english, self.W_english) + self.b
        y = activation(y_pre, self.hidden_activation)
        z_english_pre = T.dot(y, self.W_english_prime) + self.b_prime_english
        z_english = activation(z_english_pre, self.output_activation)
        L = loss(z_english, self.x_english, self.loss_fn)
        total_loss = T.mean(L)

        if self.tied:
            curr_params = [self.W_english, self.b, self.b_prime_english]
            curr_param_names = ["W_english", "b", "b_prime_english"]
        else:
            curr_params = [self.W_english, self.b, self.b_prime_english, self.W_english_prime]
            curr_param_names = ["W_english", "b", "b_prime_english", "W_english_prime"]

        gradients = T.grad(total_loss, curr_params)
        updates = []
        for p,g,n in zip(curr_params, gradients, curr_param_names):
            gr, upd = self.optimizer.get_grad_update(n,g)
            updates.append((p,p+gr))
            updates.extend(upd)
        return total_loss, updates

    def project_from_hindi(self):

        y_pre = T.dot(self.x_hindi, self.W_hindi) + self.b
        y = activation(y_pre, self.hidden_activation)
        return y

    def project_from_english(self):

        y_pre = T.dot(self.x_english, self.W_english) + self.b
        y = activation(y_pre, self.hidden_activation)
        return y

    def reconstruct_from_hindi(self):

        y_pre = T.dot(self.x_hindi, self.W_hindi) + self.b
        y = activation(y_pre, self.hidden_activation)
        z_hindi_pre = T.dot(y, self.W_hindi_prime) + self.b_prime_hindi
        z_english_pre = T.dot(y,self.W_english_prime) + self.b_prime_english
        z_hindi = activation(z_hindi_pre, self.output_activation)
        z_english = activation(z_english_pre, self.output_activation)
        return z_hindi, z_english

    def reconstruct_from_english(self):

        y_pre = T.dot(self.x_english, self.W_english) + self.b
        y = activation(y_pre, self.hidden_activation)
        z_hindi_pre = T.dot(y, self.W_hindi_prime) + self.b_prime_hindi
        z_english_pre = T.dot(y,self.W_english_prime) + self.b_prime_english
        z_hindi = activation(z_hindi_pre, self.output_activation)
        z_english = activation(z_english_pre, self.output_activation)
        return z_hindi, z_english

    def get_lr_rate(self):
        return self.optimizer.get_l_rate()

    def set_lr_rate(self,new_lr):
        self.optimizer.set_l_rate(new_lr)

    def save_matrices(self):

        for p,nm in zip(self.params, self.param_names):
            numpy.save(self.op_folder+nm, p.get_value(borrow=True))

    def save_params(self):

        params = {}
        params["optimization"] = self.optimization
        params["l_rate"] = self.l_rate
        params["n_visible_hindi"] = self.n_visible_hindi
        params["n_visible_english"] = self.n_visible_english
        params["n_hidden"] = self.n_hidden
        params["lamda"] = self.lamda
        params["hidden_activation"] = self.hidden_activation
        params["output_activation"] = self.output_activation
        params["loss_fn"] = self.loss_fn
        params["tied"] = self.tied
        params["numpy_rng"] = self.numpy_rng
        params["theano_rng"] = self.theano_rng

        pickle.dump(params,open(self.op_folder+"params.pck","wb"),-1)


    def load(self, folder, input_hindi=None, input_english=None):

        plist = pickle.load(open(folder+"params.pck","rb"))

        self.init(plist["numpy_rng"], theano_rng=plist["theano_rng"], l_rate=plist["l_rate"],
                  optimization=plist["optimization"], tied=plist["tied"],
                  n_visible_hindi=plist["n_visible_hindi"], n_visible_english=plist["n_visible_english"],
                  n_hidden=plist["n_hidden"], lamda=plist["lamda"], W_hindi=folder+"W_hindi",
                  W_english=folder+"W_english", b=folder+"b", W_hindi_prime=folder+"W_hindi_prime",
                  W_english_prime=folder+"W_english_prime", b_prime_hindi=folder+"b_prime_hindi",
                  b_prime_english=folder+"b_prime_english", input_hindi=input_hindi, input_english=input_english,
                  hidden_activation=plist["hidden_activation"], output_activation=plist["output_activation"],
                  loss_fn = plist["loss_fn"], op_folder=folder)




def trainCorrNet(src_folder, tgt_folder, batch_size = 20, training_epochs=40,
                 l_rate=0.01, optimization="sgd", tied=False, n_visible_hindi=None,
                 n_visible_english=None, n_hidden=None, lamda=5,
                 W_hindi=None, W_english=None, b=None, W_hindi_prime=None, W_english_prime=None,
                 b_prime_hindi=None, b_prime_english=None, hidden_activation="sigmoid",
                 output_activation="sigmoid", loss_fn = "squarrederror"):

    index = T.lscalar()
    x_hindi = T.matrix('x_hindi')
    x_english = T.matrix('x_english')

    rng = numpy.random.RandomState(123)
    theano_rng = RandomStreams(rng.randint(2 ** 30))

    model = CorrNet()
    model.init(numpy_rng=rng, theano_rng=theano_rng, l_rate=l_rate, optimization=optimization, tied=tied, n_visible_hindi=n_visible_hindi, n_visible_english=n_visible_english, n_hidden=n_hidden, lamda=lamda, W_hindi=W_hindi, W_english=W_english, b=b, W_hindi_prime=W_hindi_prime, W_english_prime=W_english_prime, b_prime_hindi=b_prime_hindi, b_prime_english=b_prime_english, input_hindi=x_hindi, input_english=x_english, hidden_activation=hidden_activation, output_activation=output_activation, loss_fn =loss_fn, op_folder=tgt_folder)
    
    train_set_x_hindi = theano.shared(numpy.asarray(numpy.zeros((1000,n_visible_hindi)), dtype=theano.config.floatX), borrow=True)
    train_set_x_english = theano.shared(numpy.asarray(numpy.zeros((1000,n_visible_english)), dtype=theano.config.floatX), borrow=True)

    common_total_loss, common_updates = model.train_common("1111")
    mtrain_common = theano.function([index], common_total_loss,updates=common_updates,givens=[(x_hindi, train_set_x_hindi[index * batch_size:(index + 1) * batch_size]),(x_english, train_set_x_english[index * batch_size:(index + 1) * batch_size])])

    hindi_total_loss, hindi_updates = model.train_hindi()
    mtrain_hindi = theano.function([index], hindi_total_loss,updates=hindi_updates,givens=[(x_hindi, train_set_x_hindi[index * batch_size:(index + 1) * batch_size])])

    english_total_loss, english_updates = model.train_english()
    mtrain_english = theano.function([index], english_total_loss,updates=english_updates,givens=[(x_english, train_set_x_english[index * batch_size:(index + 1) * batch_size])])


    diff = 0
    flag = 1
    detfile = open(tgt_folder+"details.txt","w")
    detfile.close()
    oldtc = float("inf")

    for epoch in xrange(training_epochs):

        print "in epoch ", epoch
        c = []
        ipfile = open(src_folder+"train/ip.txt","r")
        for line in ipfile:
            next = line.strip().split(",")
            if(next[0]=="xy"):
                if(next[1]=="dense"):
                    denseTheanoloader(next[2]+"_hindi",train_set_x_hindi,"float32")
                    denseTheanoloader(next[2]+"_english",train_set_x_english, "float32")
                else:
                    sparseTheanoloader(next[2]+"_hindi",train_set_x_hindi,"float32",1000,n_visible_hindi)
                    sparseTheanoloader(next[2]+"_english",train_set_x_english, "float32", 1000, n_visible_english)
                for batch_index in range(0,int(next[3])/batch_size):
                    c.append(mtrain_common(batch_index))
            elif(next[0]=="x"):
                if(next[1]=="dense"):
                    denseTheanoloader(next[2]+"_hindi",train_set_x_hindi,"float32")
                else:
                    sparseTheanoloader(next[2]+"_hindi",train_set_x_hindi,"float32",1000,n_visible_hindi)
                for batch_index in range(0,int(next[3])/batch_size):
                    c.append(mtrain_hindi(batch_index))
            elif(next[0]=="y"):
                if(next[1]=="dense"):
                    denseTheanoloader(next[2]+"_english",train_set_x_english,"float32")
                else:
                    sparseTheanoloader(next[2]+"_english",train_set_x_english,"float32",1000,n_visible_english)
                for batch_index in range(0,int(next[3])/batch_size):
                    c.append(mtrain_english(batch_index))


        if(flag==1):
            flag = 0
            diff = numpy.mean(c)
            di = diff
        else:
            di = numpy.mean(c) - diff
            diff = numpy.mean(c)

        print 'Difference between 2 epochs is ', di
        print 'Training epoch %d, total_loss ' % epoch, diff       

        ipfile.close()

        detfile = open(tgt_folder+"details.txt","a")
        detfile.write("train\t"+str(diff)+"\n")
        detfile.close()
        if((epoch+1)%5==0):
            model.save_matrices()
    model.save_matrices()

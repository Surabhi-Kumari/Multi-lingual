import numpy
import math
from sklearn import svm
from sklearn.metrics import accuracy_score
import sys

def svm_classifier(train_x, train_y, valid_x, valid_y, test_x, test_y):

	clf = svm.LinearSVC()
	clf.fit(train_x,train_y)
	pred = clf.predict(valid_x)
	va = accuracy_score(numpy.ravel(valid_y),numpy.ravel(pred))
	pred = clf.predict(test_x)
	ta = accuracy_score(numpy.ravel(test_y),numpy.ravel(pred))
	return va, ta

def transfer_learning_5fold(folder):

	l1 = numpy.load(folder+"test-l1.npy")
	l2 = numpy.load(folder+"test-l2.npy")
	labels = numpy.load(folder+"test-labels.npy")

	perp = len(l1)/5

	print "l1 to l2"

	acc = 0
	for i in range(0,5):
		test_x = l2[i*perp:(i+1)*perp]
		test_y = labels[i*perp:(i+1)*perp]
		if i==0:
			train_x = l1[perp:len(l1)]
			train_y = labels[perp:len(l1)]
		elif i==4:
			train_x = l1[0:4*perp]
			train_y = labels[0:4*perp]
		else:
			train_x1 = l1[0:i*perp]
			train_y1 = labels[0:i*perp]
			train_x2 = l1[(i+1)*perp:len(l1)]
			train_y2 = labels[(i+1)*perp:len(l1)]
			train_x = numpy.concatenate((train_x1,train_x2))
			train_y = numpy.concatenate((train_y1,train_y2))
		va, ta = svm_classifier(train_x, train_y, test_x, test_y, test_x, test_y)
		acc += ta
	print acc/5
	print "l2 to l1"

	acc = 0
	for i in range(0,5):
		test_x = l1[i*perp:(i+1)*perp]
		test_y = labels[i*perp:(i+1)*perp]
		if i==0:
			train_x = l2[perp:len(l1)]
			train_y = labels[perp:len(l1)]
		elif i==4:
			train_x = l2[0:4*perp]
			train_y = labels[0:4*perp]
		else:
			train_x1 = l2[0:i*perp]
			train_y1 = labels[0:i*perp]
			train_x2 = l2[(i+1)*perp:len(l1)]
			train_y2 = labels[(i+1)*perp:len(l1)]
			train_x = numpy.concatenate((train_x1,train_x2))
			train_y = numpy.concatenate((train_y1,train_y2))
		va, ta = svm_classifier(train_x, train_y, test_x, test_y, test_x, test_y)
		acc += ta
	print acc/5

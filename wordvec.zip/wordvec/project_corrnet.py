import numpy
import os
import sys

sys.path.append("../Model/")
from corrnet import *

def create_folder(folder):

	if not os.path.exists(folder):
		os.makedirs(folder)



src_folder = sys.argv[1]+"langcode/"
tgt_folder = sys.argv[2]

model = CorrNet()
model.load(tgt_folder)

create_folder(tgt_folder+"project/")

lang = numpy.load(src_folder+"train/l1.npy")
new_lang = model.proj_from_hindi(lang)
numpy.save(tgt_folder+"project/train-l1",new_lang)

lang = numpy.load(src_folder+"train/l2.npy")
new_lang = model.proj_from_english(lang)
numpy.save(tgt_folder+"project/train-l2",new_lang)

lang = numpy.load(src_folder+"train/labels.npy")
numpy.save(tgt_folder+"project/train-labels",lang)


lang = numpy.load(src_folder+"valid/l1.npy")
new_lang = model.proj_from_hindi(lang)
numpy.save(tgt_folder+"project/valid-l1",new_lang)

lang = numpy.load(src_folder+"valid/l2.npy")
new_lang = model.proj_from_english(lang)
numpy.save(tgt_folder+"project/valid-l2",new_lang)

lang = numpy.load(src_folder+"valid/labels.npy")
numpy.save(tgt_folder+"project/valid-labels",lang)


lang = numpy.load(src_folder+"test/l1.npy")
new_lang = model.proj_from_hindi(lang)
numpy.save(tgt_folder+"project/test-l1",new_lang)

lang = numpy.load(src_folder+"test/l2.npy")
new_lang = model.proj_from_english(lang)
numpy.save(tgt_folder+"project/test-l2",new_lang)

lang = numpy.load(src_folder+"test/labels.npy")
numpy.save(tgt_folder+"project/test-labels",lang)

